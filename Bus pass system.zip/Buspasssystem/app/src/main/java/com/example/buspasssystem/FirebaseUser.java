package com.example.buspasssystem;

public class FirebaseUser {
}
